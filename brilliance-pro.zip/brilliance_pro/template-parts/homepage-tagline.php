<?php cpotheme_block('home_tagline', 'tagline', 'container'); ?>
